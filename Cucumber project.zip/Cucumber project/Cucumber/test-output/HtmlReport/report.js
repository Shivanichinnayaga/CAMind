$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("file:src/test/java/Feature/Bookshelf.feature");
formatter.feature({
  "name": "Validating the search page",
  "description": "",
  "keyword": "Feature"
});
formatter.scenario({
  "name": "UrbanLadder search page",
  "description": "",
  "keyword": "Scenario"
});
formatter.step({
  "name": "open the Browser",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefiniton.open_the_browser()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Enter into the \"https://www.urbanladder.com/\" website",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefiniton.enter_into_the_website(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user need to type Bookshelf in search bar",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefiniton.user_need_to_type_bookshelf_in_search_bar()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "click on enter1",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefiniton.click_on_enter1()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "close the website",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefiniton.close_the_website()"
});
formatter.result({
  "status": "passed"
});
formatter.uri("file:src/test/java/Feature/Decor.feature");
formatter.feature({
  "name": "Entering the Decor link",
  "description": "",
  "keyword": "Feature"
});
formatter.scenario({
  "name": "UrbanLadder decor link",
  "description": "",
  "keyword": "Scenario"
});
formatter.step({
  "name": "open the Browser",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefiniton.open_the_browser()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Enter into the \"https://www.urbanladder.com/\" website",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefiniton.enter_into_the_website(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "click on decorlink",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefiniton.click_on_decorlink()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "click on carpetslink",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefiniton.click_on_carpetslink()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "close the website",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefiniton.close_the_website()"
});
formatter.result({
  "status": "passed"
});
formatter.uri("file:src/test/java/Feature/Storage.feature");
formatter.feature({
  "name": "Entering the storage link",
  "description": "",
  "keyword": "Feature"
});
formatter.scenario({
  "name": "UrbanLadder Storage link",
  "description": "",
  "keyword": "Scenario"
});
formatter.step({
  "name": "open the Browser",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefiniton.open_the_browser()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Enter into the \"https://www.urbanladder.com/\" website",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefiniton.enter_into_the_website(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "click on Storagelink",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefiniton.click_on_storagelink()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "click on cupboardslink",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefiniton.click_on_cupboardslink()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "close the website",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefiniton.close_the_website()"
});
formatter.result({
  "status": "passed"
});
formatter.uri("file:src/test/java/Feature/Study.feature");
formatter.feature({
  "name": "Entering the study link",
  "description": "",
  "keyword": "Feature"
});
formatter.scenario({
  "name": "UrbanLadder Study link",
  "description": "",
  "keyword": "Scenario"
});
formatter.step({
  "name": "open the Browser",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefiniton.open_the_browser()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Enter into the \"https://www.urbanladder.com/\" website",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefiniton.enter_into_the_website(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "click on Studylink",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefiniton.click_on_studylink()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "click on studylamplink",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefiniton.click_on_studylamplink()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "close the website",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefiniton.close_the_website()"
});
formatter.result({
  "status": "passed"
});
formatter.uri("file:src/test/java/Feature/contactus.feature");
formatter.feature({
  "name": "Entering into contact us link",
  "description": "",
  "keyword": "Feature"
});
formatter.scenario({
  "name": "UrbanLadder contactus link",
  "description": "",
  "keyword": "Scenario"
});
formatter.step({
  "name": "open the Browser",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefiniton.open_the_browser()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Enter into the \"https://www.urbanladder.com/\" website",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefiniton.enter_into_the_website(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "click on contactus link",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefiniton.click_on_contactus_link()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "close the website",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefiniton.close_the_website()"
});
formatter.result({
  "status": "passed"
});
formatter.uri("file:src/test/java/Feature/gift.feature");
formatter.feature({
  "name": "Entering into giftandcards link",
  "description": "",
  "keyword": "Feature"
});
formatter.scenario({
  "name": "UrbanLadder giftandcards link",
  "description": "",
  "keyword": "Scenario"
});
formatter.step({
  "name": "open the Browser",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefiniton.open_the_browser()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Enter into the \"https://www.urbanladder.com/\" website",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefiniton.enter_into_the_website(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "click on giftandcards link",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefiniton.click_on_giftandcards_link()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "click on housewarming link",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefiniton.click_on_housewarming_link()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "close the website",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefiniton.close_the_website()"
});
formatter.result({
  "status": "passed"
});
formatter.uri("file:src/test/java/Feature/help.feature");
formatter.feature({
  "name": "Entering to help link",
  "description": "",
  "keyword": "Feature"
});
formatter.scenario({
  "name": "Urbanladder help link",
  "description": "",
  "keyword": "Scenario"
});
formatter.step({
  "name": "open the Browser",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefiniton.open_the_browser()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Enter into the \"https://www.urbanladder.com/\" website",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefiniton.enter_into_the_website(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "click on help link",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefiniton.click_on_help_link()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user need to type How do I order cancel in search bar",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefiniton.user_need_to_type_how_do_i_order_cancel_in_search_bar()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "click on Enter",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefiniton.click_on_Enter()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "close the website",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefiniton.close_the_website()"
});
formatter.result({
  "status": "passed"
});
formatter.uri("file:src/test/java/Feature/login.feature");
formatter.feature({
  "name": "Entering into urban",
  "description": "",
  "keyword": "Feature"
});
formatter.scenario({
  "name": "urban Sign page",
  "description": "",
  "keyword": "Scenario"
});
formatter.step({
  "name": "open the Browser",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefiniton.open_the_browser()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Enter into the \"https://www.urbanladder.com/\" website",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefiniton.enter_into_the_website(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user need to click on profile icon",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefiniton.user_need_to_click_on_profile_icon()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user need to click on login",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefiniton.user_need_to_click_on_login()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user send email",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefiniton.user_send_email()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "user send password",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefiniton.user_send_password()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "click on login",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefiniton.click_on_login()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "close the website",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefiniton.close_the_website()"
});
formatter.result({
  "status": "passed"
});
formatter.uri("file:src/test/java/Feature/loginpage.feature");
formatter.feature({
  "name": "Entering into sale",
  "description": "",
  "keyword": "Feature"
});
formatter.scenario({
  "name": "UrbanLadder sale link",
  "description": "",
  "keyword": "Scenario"
});
formatter.step({
  "name": "open the Browser",
  "keyword": "Given "
});
formatter.match({
  "location": "StepDefiniton.open_the_browser()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Enter into the \"https://www.urbanladder.com/\" website",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefiniton.enter_into_the_website(String)"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "click on sales",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefiniton.click_on_sales()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "click on sofa in dropdown",
  "keyword": "And "
});
formatter.match({
  "location": "StepDefiniton.click_on_sofa_in_dropdown()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "close the website",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefiniton.close_the_website()"
});
formatter.result({
  "status": "passed"
});
});