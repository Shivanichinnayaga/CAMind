/*package Utilities;

import java.io.ObjectInputFilter.Config;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;





public class BaseClass {
	public WebDriver driver;
	public Config co;
	
	

	
	
	@BeforeSuite
	public void start() throws Exception
	{
		co=new Config();
		er=new Extentreport();
		oc=new Helpclass();
		
		
		
	}
	
	@BeforeClass
	public WebDriver setup()
	{
		return driver= Parentclass.Application(driver, co.getBrowser(),co.getURL());
	}
	
	@AfterClass
	public void close() {
		Parentclass.quitBrowser(driver);
	}
		

}
*/