package StepDefinitions;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import Pageobject.Bookshelf;
import Pageobject.Collection;
import Pageobject.Decor;
import Pageobject.Giftcards;
import Pageobject.Shoeracks;
import Pageobject.Sign;
import Pageobject.contactus;
import Pageobject.sale;
import Pageobject.storage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
 


public class StepDefiniton {
  public WebDriver driver;

	@Given("open the Browser")
	public void open_the_browser() {
		System.setProperty("webdriver.chrome.driver", "./Drivers/chromedriver.exe");
		driver = new ChromeDriver();
	}

	@Given("Enter into the {string} website")
	public void enter_into_the_website(String site) {
		driver.get(site);
	}

	@Given("user need to type Bookshelf in search bar")
	public void user_need_to_type_bookshelf_in_search_bar() {
		Bookshelf bs = new Bookshelf(driver);
		bs.Bookshelf1().sendKeys("Bookshelf");
		bs.searchicon1().click();
	}

	@Given("click on enter1")
	public void click_on_enter1() {
		Bookshelf bs = new Bookshelf(driver);
		bs.searchicon1().click();
	}

	@Then("close the website")
	public void close_the_website() {
		driver.close();
	}

	@Given("click on decorlink")
	public void click_on_decorlink() throws InterruptedException {
		Decor d = new Decor(driver);
		d.decor1().click();
		Thread.sleep(2000);
		
	}

	@Given("click on carpetslink")
	public void click_on_carpetslink() throws InterruptedException {
		Decor d = new Decor(driver);
		Thread.sleep(2000);
		d.carpets1().click();
	}

	@Given("click on Storagelink")
	public void click_on_storagelink() throws InterruptedException {
		storage sgg = new storage(driver);
		sgg.Storage1().click();
		Thread.sleep(2000);
		
	}

	@Given("click on cupboardslink")
	public void click_on_cupboardslink() {
		storage sgg = new storage(driver);
		sgg.cupboards2().click();
	}

	@Given("click on Studylink")
	public void click_on_studylink() throws InterruptedException {
		Collection cc = new Collection(driver);
		cc.collection1().click();
		Thread.sleep(2000);
		
	}

	@Given("click on studylamplink")
	public void click_on_studylamplink() {
		Collection cc = new Collection(driver);
		cc.gakurange1().click();
	}

	@Given("click on contactus link")
	public void click_on_contactus_link() throws InterruptedException {
		contactus cu = new contactus(driver);
		Thread.sleep(2000);
		cu.contactus1().click();
	}

	@Given("click on giftandcards link")
	public void click_on_giftandcards_link() {
		Giftcards tw = new Giftcards(driver);
		tw.gift1().click();
		
	}

	@Given("click on housewarming link")
	public void click_on_housewarming_link() {
		Giftcards tw = new Giftcards(driver);
		tw.house1().click();

	}

	@Given("click on help link")
	public void click_on_help_link() throws InterruptedException {
		Shoeracks sr = new Shoeracks(driver);
		Thread.sleep(2000);
		sr.shoe1().click();

	}

	@Given("user need to type How do I order cancel in search bar")
	public void user_need_to_type_how_do_i_order_cancel_in_search_bar() {
		Shoeracks sr = new Shoeracks(driver);
		sr.helpsearch1().sendKeys("How do I cancel order?");
	}

	@Given("click on Enter")
	public void click_on_Enter() throws InterruptedException {
		Shoeracks sr = new Shoeracks(driver);
		Thread.sleep(2000);
		sr.icon1().click();
	} 
	
	@Given("user need to click on profile icon")
	public void user_need_to_click_on_profile_icon()  {
		Sign sg = new Sign(driver);
		sg.person1().click();

	}

	@Given("user need to click on login")
	public void user_need_to_click_on_login() throws InterruptedException  {
		Sign sg = new Sign(driver);
		Thread.sleep(5000);
		sg.login1().click();
	}
	@Given("user send email")
	public void user_send_email() throws InterruptedException{
		Sign sg = new Sign(driver);
		Thread.sleep(5000);
		sg.email1().sendKeys("shivaniyaga@gmail.com");

	}

	@Given("user send password")
	public void user_send_password() {
		Sign sg = new Sign(driver);
		sg.password1().sendKeys("1234@shivu");
		
	
	}

	@Then("click on login")
	public void click_on_login() {
		Sign sg = new Sign(driver);
		sg.loginid1().click();
	}
	
	@Given("click on sales")
	public void click_on_sales() throws InterruptedException {
		sale s = new sale(driver);
		s.sale1().click();
		Thread.sleep(2000);
		
	}

	@Given("click on sofa in dropdown")
	public void click_on_sofa_in_dropdown() {
		sale s = new sale(driver);
		s.sofa1().click();
	} 

}
