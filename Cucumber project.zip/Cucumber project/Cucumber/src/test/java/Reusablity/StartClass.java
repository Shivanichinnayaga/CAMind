package Reusablity;



import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;


public class StartClass {
	public WebDriver driver;
	
	public StartClass(WebDriver driver)
	{
		this.driver=driver;
	}
	public void startBrowser()
	{
		System.setProperty("webdriver.chrome.driver","./Driver/chromedriver.exe");
		WebDriver driver= new ChromeDriver();
		driver.get("https://www.urbanladder.com/");
		
	}
	 public void getUrl(String site)
	    {
	     driver.get("https://www.urbanladder.com/");	
	    }
	    public WebElement person1()
		{
			return driver.findElement(By.xpath("//span[@ class='header-icon-link user-profile-icon'] "));
			
		}
	    public WebElement login1()
		{
			return driver.findElement(By.linkText("Log In"));
			
		}
		public WebElement email1()
		{
			return driver.findElement(By.xpath("//*[@class='email required input_authentication']"));
			
		}
		public WebElement password1()
		{
			return driver.findElement(By.xpath("//*[@class='required input_authentication']"));
			
		}
		public WebElement loginid1()
		{
			return driver.findElement(By.id("ul_site_login"));
			
		}
		public WebElement Bookshelf1() {
			return driver.findElement( By.id("search"));

		}

		public WebElement searchicon1() {
			return driver.findElement(By.xpath("//span[@class='search-icon icofont-search']") );
		}

}
